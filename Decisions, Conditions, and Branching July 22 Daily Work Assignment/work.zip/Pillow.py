num = int(input(" How many pillows would you like to purchase:> "))
shipping = int(input("What type of shipping would you like 1: Regular [$1.25 per pillow] 2: priority [$2.00 per pillow] note priority has a extra charge of 60$"))
pcost = 0
cost = 0.0
scost = 0
tax = 0.0

if num <= 10:
    cost = num * 21.0
elif num > 10:
    cost = num * 15.58
pcost = cost


if shipping == 1:
    scost = num * 1.25
    cost = cost + scost
elif shipping == 2:
    scost = scost + num * 2.0 + 60
    cost = cost + scost
tax = pcost * 0.15

print("Product Cost: $" + '{:1,.2f}'.format(pcost))
print("Shipping Cost: $" + '{:1,.2f}'.format(scost))
print("Subtotal: $" + '{:1,.2f}'.format(pcost + scost))
print("Tax: $" + '{:1,.2f}'.format(tax))
print("Total: $" + '{:1,.2f}'.format(cost + tax))


