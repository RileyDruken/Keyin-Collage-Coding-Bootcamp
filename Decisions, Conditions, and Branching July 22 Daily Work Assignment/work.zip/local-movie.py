user_age: int = int(input("What is your age? :>"))

if user_age < 13:
    print("the cost of admission is $1.00 you can see G rated movies")
elif 13 <= user_age <= 17:
    print("the cost of admission is $5.00 you can see PG-13 rated movies or G rated movies")
elif 18 <= user_age <= 59:
    print("the cost of admission is $10.00 and you see any movies unrestricted")
elif user_age >= 60:
    print("the cost of admission is $3.50 and you see any movies unrestricted")