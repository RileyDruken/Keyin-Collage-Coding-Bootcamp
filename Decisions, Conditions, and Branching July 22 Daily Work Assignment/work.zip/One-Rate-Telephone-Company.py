http_code = "418"

call_location = input("Call_Location :>")
call_time = float(input("Call Time in mins:>"))
call_cost = 0.05 * call_time + call_time + 1.30
call_destination = input("Call_Destination :>")
if call_time <= 0:
    print("Error time is zero or less")
else:
    print(call_location)
    print(call_time)
    print(call_cost)
    print(call_destination)
